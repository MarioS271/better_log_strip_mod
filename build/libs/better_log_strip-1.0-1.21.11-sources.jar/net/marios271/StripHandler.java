package net.marios271;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1743;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;

public class StripHandler {
    private static class_2338 lastPos = null;
    private static long lastTime = 0;
    private static final long WINDOW_MS = 500;

    public static void register() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.method_8608())
                return class_1269.field_5811;

            class_1799 held = player.method_5998(hand);
            class_2338 pos = hitResult.method_17777();
            class_2680 state = world.method_8320(pos);

            if (!(held.method_7909() instanceof class_1743))
                return class_1269.field_5811;

            if (!class_1743.field_7898.containsKey(state.method_26204()))
                return class_1269.field_5811;

            long now = System.currentTimeMillis();

            if (pos.equals(lastPos) && (now - lastTime) < WINDOW_MS) {
                player.method_7353(class_2561.method_43473(), true);

                lastPos = null;
                return class_1269.field_5811;
            } else {
                player.method_7353(class_2561.method_43471("message.better_log_strip.click_again"), true);

                lastPos = pos;
                lastTime = now;
                return class_1269.field_5814;
            }
        });
    }
}
